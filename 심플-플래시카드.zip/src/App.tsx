/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Plus, RotateCcw } from 'lucide-react';

const initialCards = [
  {
    id: 1,
    title: "오늘의 ADP 포인트",
    content: "4일차: [제3과목] p-value - 0.05보다 작으면 귀무가설 기각, '통계적으로 유의미하다'고 해석."
  },
  {
    id: 2,
    title: "오늘의 ADP 포인트",
    content: "5일차: [제2과목] 결측치 처리 - 단순 대치법, 다중 대치법 등 상황에 맞는 적절한 처리 방법을 선택하여 분석의 정확도를 높임."
  },
  {
    id: 3,
    title: "머신러닝 핵심 개념",
    content: "과적합(Overfitting): 모델이 학습 데이터에만 너무 맞춰져서 새로운 데이터(테스트 데이터)에 대한 예측 성능이 떨어지는 현상."
  }
];

export default function App() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextCard = () => {
    setCurrentIndex((prev) => (prev + 1) % initialCards.length);
  };

  const prevCard = () => {
    setCurrentIndex((prev) => (prev - 1 + initialCards.length) % initialCards.length);
  };

  return (
    <div className="min-h-screen bg-[#050608] text-slate-200 flex flex-col items-center justify-center p-6 font-sans relative overflow-hidden">
      {/* Background Atmosphere */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-600/10 rounded-full blur-[150px] pointer-events-none z-0"></div>
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] z-0" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>

      <div className="w-full max-w-3xl relative z-10">
        {/* Main Card Area */}
        <div className="relative group">
          {/* Outer Glow */}
          <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-[40px] blur opacity-20 transition-opacity duration-500 group-hover:opacity-30"></div>
          
          <div className="relative min-h-[250px] sm:min-h-[200px] flex items-center bg-[#0d1117] border border-slate-800 rounded-[32px] shadow-2xl p-8 sm:p-12 overflow-hidden overflow-x-hidden text-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="w-full"
              >
                <h2 className="text-white text-2xl sm:text-3xl font-bold mb-6 tracking-tight drop-shadow-sm break-keep">
                  {initialCards[currentIndex].title}
                </h2>
                <p className="text-slate-400 text-lg sm:text-xl leading-relaxed font-light break-keep">
                  {initialCards[currentIndex].content}
                </p>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Navigation Controls (Mobile optimized too) */}
        <div className="flex justify-between items-center mt-12">
          <button
            onClick={prevCard}
            className="flex items-center gap-2 h-14 px-4 sm:px-6 rounded-full border border-slate-800 bg-slate-900/50 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors active:scale-95 focus:outline-none"
          >
            <ChevronLeft size={24} />
            <span className="hidden sm:inline font-medium">이전 부분</span>
          </button>
          
          {/* Indicators */}
          <div className="flex justify-center gap-2 flex-wrap max-w-[150px] sm:max-w-none justify-center">
            {initialCards.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`h-1.5 rounded-full transition-all duration-300 focus:outline-none ${
                  idx === currentIndex ? 'w-8 bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]' : 'w-2 bg-slate-800 hover:bg-slate-600'
                }`}
                aria-label={`Go to card ${idx + 1}`}
              />
            ))}
          </div>

          <button
            onClick={nextCard}
            className="flex items-center gap-2 h-14 px-4 sm:px-6 rounded-full border border-slate-800 bg-slate-900/50 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors active:scale-95 focus:outline-none"
          >
            <span className="hidden sm:inline font-medium">다음 포인트</span>
            <ChevronRight size={24} />
          </button>
        </div>
      </div>
    </div>
  );
}
